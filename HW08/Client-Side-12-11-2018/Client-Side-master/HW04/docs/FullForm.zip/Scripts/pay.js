"use strict";

/**
 * Gets the element on the page with the given id.
 *
 * @param {String} id the id of the element to get.
 *
 * @returns {HTMLElement} the element with the given id.
 */
function $(id) {
    return document.getElementById(id);
}

function calculateGrossPay(hours, rate) {
    if (hours > 40.0) {
        var gross = 40.0 * rate;
        return gross + ((hours - 40.0) * (rate * 1.5));
    } else {
        return hours * rate;
    }
}

function formatCurrency(value) {
    if (!isNaN(value)) {
        return "$ " + value.toFixed(2);
    } else {
        return "$ 0.0";
    }
}

function processEntry() {

    $("results").style.visibility = "visible";

   var name = $("name").value;
   var hours = parseFloat($("hours").value);
   var rate = parseFloat($("rate").value);

   var row = $("name_row").getElementsByTagName("td");
   row[1].innerHTML = name;

   var gross = formatCurrency(calculateGrossPay(hours, rate));
   row = $("hours_row").getElementsByTagName("td");
   row[1].innerHTML = hours;

   row = $("rate_row").getElementsByTagName("td");
   row[1].innerHTML = formatCurrency(rate);

   row =$("gross_row").getElementsByTagName("td");
   row[1].innerHTML = gross;
}

function verifyHours() {
    var hours = $("hours");
    var value = parseFloat(hours.value);

    if (isNaN(value) || value <= 0.0) {
        // value is invalid!
        hours.nextElementSibling.innerHTML = "Invalid hours!";
    } else {
        hours.nextElementSibling.innerHTML = "";
    }
}

function resetForm() {
    $("payForm").reset();
    $("hours").nextElementSibling.innerHTML = "*";
    // do the same for rate and name if needed.
    $("name").focus();
    $("results").style.visibility = "hidden";
}

window.onload = function() {
   $("submitButton").onclick = processEntry;
   $("hours").onblur = verifyHours;
   $("clearButton").onclick = resetForm;
   $("name").focus();
};