// library_cards.js
// student: Sherrie Teague
// date: 11/27/2018
// class: Client-Side Programming
// assignment: HW08 Pulling It All Together

//The library_cards.js file should create a cards object that works with
// the cards. This object should contain the functions that preload
// and store images, store the src attributes for the cards, create the HTML
// for the cards, flip a card using a fade effect, and flip a
// card using a slide effect.

// In addition, the application should use strings throughout the application
// to specify the src attributes for the card back and blank card,
// these attributes are stored in variables in this library.