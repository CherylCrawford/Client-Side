// main.js
// student: Sherrie Teague
// date: 11/27/2018
// class: Client-Side Programming
// assignment: HW08 Pulling It All Together

/*Use an images array to store the images for the cards used
by a game.*/
    var imgArray = [
    'images/card_1.png',
    'images/card_2.png',
    'images/card_3.png',
    'images/card_4.png',
    'images/card_5.png',
    'images/card_6.png',
    'images/card_7.png',
    'images/card_8.png',
    'images/card_9.png',
    'images/card_10.png',
    'images/card_11.png',
    'images/card_12.png',
    'images/card_13.png',
    'images/card_14.png',
    'images/card_15.png',
    'images/card_16.png',
    'images/card_17.png',
    'images/card_18.png',
    'images/card_19.png',
    'images/card_20.png',
    'images/card_21.png',
    'images/card_22.png',
    'images/card_23.png',
    'images/card_24.png'
    ];

/*Use a cards array to store the src attributes of the images
for the cards that will be displayed on the board (two for
    each image).*/
var cardsArray = [

];

